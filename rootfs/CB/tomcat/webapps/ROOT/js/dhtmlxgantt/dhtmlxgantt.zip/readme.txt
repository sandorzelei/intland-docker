

Useful links
-------------

- Online  documentation
	http://docs.dhtmlx.com/gantt/

- Downloadable documentation
	CHM version
		http://dhtmlx.com/x/download/regular/dhtmlxgantt_chm.zip
	HTML version
		http://dhtmlx.com/x/download/regular/dhtmlxgantt_docs_html.zip
	
- Support forum
	http://forum.dhtmlx.com/viewforum.php?f=15